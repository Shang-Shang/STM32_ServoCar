rem --- Component "STM32F103C8T6" ---
newgenasym.exe -i "%cd%\exported\stm32f103c8t6" -n "stm32f103c8t6"
van.exe -q -nolinks -sironly "%cd%\exported\stm32f103c8t6\entity\verilog.v" -lib "exported_lib" -view entity -cdslib "%cd%\exported_lib.lib"

Pause
