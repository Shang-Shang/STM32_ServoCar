rem --- Component "SS34" ---
newgenasym.exe -i "%cd%\exported\ss34" -n "ss34"
van.exe -q -nolinks -sironly "%cd%\exported\ss34\entity\verilog.v" -lib "exported_lib" -view entity -cdslib "%cd%\exported_lib.lib"

Pause
