SMD_8MHz.dra
